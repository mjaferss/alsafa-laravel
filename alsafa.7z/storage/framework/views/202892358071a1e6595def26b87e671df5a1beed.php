

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h3 class="mb-0"><?php echo e(__('towers.list_title')); ?></h3>
                    <a href="<?php echo e(route('towers.create')); ?>" class="btn btn-primary">
                        <?php echo e(__('towers.add_new')); ?>

                    </a>
                </div>

                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(isset($error)): ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e($error); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(isset($message)): ?>
                        <div class="alert alert-info" role="alert">
                            <?php echo e($message); ?>

                        </div>
                    <?php endif; ?>

                    <?php if($towers->isNotEmpty()): ?>
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th><?php echo e(__('towers.name_ar')); ?></th>
                                        <th><?php echo e(__('towers.name_en')); ?></th>
                                        <th><?php echo e(__('towers.branch')); ?></th>
                                        <th><?php echo e(__('towers.floors_count')); ?></th>
                                        <th><?php echo e(__('towers.apartments_per_floor')); ?></th>
                                        <th><?php echo e(__('towers.status')); ?></th>
                                        <th><?php echo e(__('towers.actions')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $towers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tower): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($tower->name_ar); ?></td>
                                            <td><?php echo e($tower->name_en); ?></td>
                                            <td><?php echo e(app()->getLocale() == 'ar' ? $tower->branch->name_ar : $tower->branch->name_en); ?></td>
                                            <td><?php echo e($tower->floors_count); ?></td>
                                            <td><?php echo e($tower->apartments_per_floor); ?></td>
                                            <td>
                                                <span class="badge bg-<?php echo e($tower->status === 'active' ? 'success' : ($tower->status === 'under_maintenance' ? 'warning' : 'danger')); ?>">
                                                    <?php echo e(__('towers.status_' . $tower->status)); ?>

                                                </span>
                                            </td>
                                            <td>
                                                <div class="btn-group" role="group">
                                                    <a href="<?php echo e(route('towers.edit', $tower)); ?>" class="btn btn-sm btn-primary">
                                                        <?php echo e(__('common.edit')); ?>

                                                    </a>
                                                    <form action="<?php echo e(route('towers.destroy', $tower)); ?>" method="POST" class="d-inline">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('<?php echo e(__('common.confirm_delete')); ?>')">
                                                            <?php echo e(__('common.delete')); ?>

                                                        </button>
                                                    </form>
                                                    <form action="<?php echo e(route('towers.toggle-status', $tower)); ?>" method="POST" class="d-inline">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PATCH'); ?>
                                                        <button type="submit" class="btn btn-sm btn-<?php echo e($tower->status === 'active' ? 'warning' : 'success'); ?>">
                                                            <?php echo e($tower->status === 'active' ? __('towers.deactivate') : __('towers.activate')); ?>

                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="mt-3">
                            <?php echo e($towers->links()); ?>

                        </div>

                        <?php if(isset($total_count)): ?>
                            <div class="mt-3">
                                <p class="text-muted">
                                    <?php echo e(__('towers.total_count', ['count' => $total_count])); ?>

                                </p>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin_new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\alsafa\resources\views/towers/index.blade.php ENDPATH**/ ?>