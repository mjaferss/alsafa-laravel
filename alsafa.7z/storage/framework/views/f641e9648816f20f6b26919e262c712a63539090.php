<?php $__env->startSection('title', __('auth.login')); ?>

<?php $__env->startSection('content'); ?>
<div class="auth-wrapper">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="auth-card">
                    <div class="card-body p-4 p-lg-5">
                        <div class="auth-header">
                            <img src="<?php echo e(asset('images/logo.jpeg')); ?>" alt="AlSafa Logo">
                            <h4><?php echo e(__('auth.login_welcome')); ?></h4>
                            <p class="text-muted"><?php echo e(__('auth.login_message')); ?></p>
                        </div>

                        <?php if(session('status')): ?>
                            <div class="alert alert-success mb-4">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mb-4">
                                <?php echo e(__('auth.messages.'.$message)); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>

                            <!-- Email Address -->
                            <div class="form-floating mb-4">
                                <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="<?php echo e(__('auth.email')); ?>" required autofocus>
                                <label for="email"><?php echo e(__('auth.email')); ?></label>
                            </div>

                            <!-- Password -->
                            <div class="form-floating mb-4">
                                <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password" name="password" placeholder="<?php echo e(__('auth.password')); ?>" required>
                                <label for="password"><?php echo e(__('auth.password')); ?></label>
                            </div>

                            <!-- Remember Me -->
                            <div class="d-flex justify-content-between align-items-center mb-4">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember">
                                    <label class="form-check-label" for="remember">
                                        <?php echo e(__('auth.remember_me')); ?>

                                    </label>
                                </div>

                                <?php if(Route::has('password.request')): ?>
                                    <a class="text-decoration-none" href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('auth.forgot_password')); ?>

                                    </a>
                                <?php endif; ?>
                            </div>

                            <button type="submit" class="btn btn-primary w-100 py-3 mb-4">
                                <i class="fas fa-sign-in-alt me-2"></i>
                                <?php echo e(__('auth.login')); ?>

                            </button>

                            <?php if(Route::has('register')): ?>
                                <div class="text-center">
                                    <p class="mb-0"><?php echo e(__('auth.no_account')); ?>

                                        <a href="<?php echo e(route('register')); ?>" class="text-primary text-decoration-none">
                                            <?php echo e(__('auth.register')); ?>

                                        </a>
                                    </p>
                                </div>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\alsafa\resources\views/auth/login.blade.php ENDPATH**/ ?>