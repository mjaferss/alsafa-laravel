

<?php $__env->startSection('title', __('apartments.list')); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><?php echo e(__('apartments.list_title')); ?></h5>
                <?php if(in_array(auth()->user()->role, ['super_admin', 'manager'])): ?>
                    <a href="<?php echo e(route('admin.apartments.create')); ?>" class="btn btn-primary btn-sm">
                        <i class="fas fa-plus me-2"></i> <?php echo e(__('apartments.add_new')); ?>

                    </a>
                <?php endif; ?>
            </div>
            <div class="mt-3">
                <form action="<?php echo e(route('admin.apartments.index')); ?>" method="GET" class="row g-3">
                    <div class="col-md-3">
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-search"></i></span>
                            <input type="text" class="form-control" name="search" placeholder="<?php echo e(__('common.search')); ?>" value="<?php echo e(request('search')); ?>">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <select class="form-select" name="tower_id">
                            <option value=""><?php echo e(__('apartments.select_tower')); ?></option>
                            <?php $__currentLoopData = $towers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tower): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tower->id); ?>" <?php echo e(request('tower_id') == $tower->id ? 'selected' : ''); ?>>
                                    <?php echo e(app()->getLocale() == 'ar' ? $tower->name_ar : $tower->name_en); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select class="form-select" name="apartment_type_id">
                            <option value=""><?php echo e(__('apartments.select_type')); ?></option>
                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($type->id); ?>" <?php echo e(request('apartment_type_id') == $type->id ? 'selected' : ''); ?>>
                                    <?php echo e(app()->getLocale() == 'ar' ? $type->name_ar : $type->name_en); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100"><?php echo e(__('common.search')); ?></button>
                    </div>
                    <div class="col-md-1">
                        <a href="<?php echo e(route('admin.apartments.index')); ?>" class="btn btn-secondary w-100">
                            <i class="fas fa-redo"></i>
                        </a>
                    </div>
                </form>
            </div>
        </div>
        <div class="card-body px-0 pt-0 pb-2">
            <div class="table-responsive p-0">
                <table class="table align-items-center mb-0">
                    <thead>
                        <tr>
                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                <?php echo e(__('apartments.fields.name')); ?>

                            </th>
                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                <?php echo e(__('apartments.fields.tower')); ?>

                            </th>
                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                <?php echo e(__('apartments.fields.type')); ?>

                            </th>
                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 d-none d-md-table-cell">
                                <?php echo e(__('apartments.fields.floor_number')); ?>

                            </th>
                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 d-none d-md-table-cell">
                                <?php echo e(__('apartments.fields.cost')); ?>

                            </th>
                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 d-none d-md-table-cell">
                                <?php echo e(__('apartments.fields.created_at')); ?>

                            </th>
                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 text-center">
                                <?php echo e(__('common.actions')); ?>

                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $apartments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apartment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="align-middle">
                                <div class="d-flex px-2 py-1">
                                    <div class="d-flex flex-column justify-content-center">
                                        <h6 class="mb-0 text-sm"><?php echo e($apartment->name); ?></h6>
                                    </div>
                                </div>
                            </td>
                            <td class="align-middle">
                                <p class="text-sm mb-0">
                                    <?php echo e(app()->getLocale() == 'ar' ? $apartment->tower->name_ar : $apartment->tower->name_en); ?>

                                </p>
                            </td>
                            <td class="align-middle">
                                <p class="text-sm mb-0">
                                    <?php echo e(app()->getLocale() == 'ar' ? $apartment->type->name_ar : $apartment->type->name_en); ?>

                                </p>
                            </td>
                            <td class="align-middle d-none d-md-table-cell">
                                <p class="text-sm mb-0"><?php echo e($apartment->floor_number); ?></p>
                            </td>
                            <td class="align-middle d-none d-md-table-cell">
                                <p class="text-sm mb-0"><?php echo e($apartment->cost); ?></p>
                            </td>
                            <td class="align-middle d-none d-md-table-cell">
                                <p class="text-sm font-weight-bold mb-0"><?php echo e($apartment->created_at->format('Y-m-d')); ?></p>
                            </td>
                            <td class="align-middle text-center text-sm">
                                <div class="dropdown">
                                    <button class="btn btn-link text-secondary mb-0" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        <i class="fa fa-ellipsis-v text-xs"></i>
                                    </button>
                                    <ul class="dropdown-menu dropdown-menu-end" style="position: absolute; z-index: 1000;">
                                        <li>
                                            <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#viewApartmentModal<?php echo e($apartment->id); ?>">
                                                <i class="fas fa-eye me-2"></i> <?php echo e(__('apartments.actions.view')); ?>

                                            </a>
                                        </li>
                                        <?php if(in_array(auth()->user()->role, ['super_admin', 'manager'])): ?>
                                            <li>
                                                <a class="dropdown-item" href="<?php echo e(route('admin.apartments.edit', $apartment)); ?>">
                                                    <i class="fas fa-edit me-2"></i> <?php echo e(__('apartments.actions.edit')); ?>

                                                </a>
                                            </li>
                                            <li>
                                                <form action="<?php echo e(route('admin.apartments.destroy', $apartment)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="dropdown-item" onclick="return confirm('<?php echo e(__('apartments.confirmations.delete')); ?>')">
                                                        <i class="fas fa-trash me-2"></i> <?php echo e(__('apartments.actions.delete')); ?>

                                                    </button>
                                                </form>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </td>
                        </tr>

                        <!-- View Apartment Modal -->
                        <div class="modal fade" id="viewApartmentModal<?php echo e($apartment->id); ?>" tabindex="-1" aria-labelledby="viewApartmentModalLabel<?php echo e($apartment->id); ?>" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="viewApartmentModalLabel<?php echo e($apartment->id); ?>"><?php echo e(__('apartments.details')); ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="card card-body">
                                            <div class="row mt-4">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label class="form-control-label"><?php echo e(__('apartments.fields.name')); ?></label>
                                                        <p class="form-control-static"><?php echo e($apartment->name); ?></p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="form-control-label"><?php echo e(__('apartments.fields.tower')); ?></label>
                                                        <p class="form-control-static">
                                                            <?php echo e(app()->getLocale() == 'ar' ? $apartment->tower->name_ar : $apartment->tower->name_en); ?>

                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="form-control-label"><?php echo e(__('apartments.fields.type')); ?></label>
                                                        <p class="form-control-static">
                                                            <?php echo e(app()->getLocale() == 'ar' ? $apartment->type->name_ar : $apartment->type->name_en); ?>

                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="form-control-label"><?php echo e(__('apartments.fields.floor_number')); ?></label>
                                                        <p class="form-control-static"><?php echo e($apartment->floor_number); ?></p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="form-control-label"><?php echo e(__('apartments.fields.cost')); ?></label>
                                                        <p class="form-control-static"><?php echo e($apartment->cost); ?></p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="form-control-label"><?php echo e(__('apartments.fields.created_at')); ?></label>
                                                        <p class="form-control-static"><?php echo e($apartment->created_at->format('Y-m-d H:i')); ?></p>
                                                    </div>
                                                </div>

                                                <!-- بيانات المستفيد -->
                                                <div class="col-12 mt-4">
                                                    <h6 class="mb-3"><?php echo e(__('apartments.beneficiary_info')); ?></h6>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="form-control-label"><?php echo e(__('apartments.fields.beneficiary_type')); ?></label>
                                                        <p class="form-control-static">
                                                            <?php if($apartment->beneficiary_type): ?>
                                                                <?php echo e(__('apartments.beneficiary_types.' . $apartment->beneficiary_type)); ?>

                                                            <?php else: ?>
                                                                -
                                                            <?php endif; ?>
                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="form-control-label"><?php echo e(__('apartments.fields.beneficiary_id')); ?></label>
                                                        <p class="form-control-static"><?php echo e($apartment->beneficiary_id ?? '-'); ?></p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="form-control-label"><?php echo e(__('apartments.fields.beneficiary_name_ar')); ?></label>
                                                        <p class="form-control-static"><?php echo e($apartment->beneficiary_name_ar ?? '-'); ?></p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="form-control-label"><?php echo e(__('apartments.fields.beneficiary_name_en')); ?></label>
                                                        <p class="form-control-static"><?php echo e($apartment->beneficiary_name_en ?? '-'); ?></p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="form-control-label"><?php echo e(__('apartments.fields.beneficiary_mobile')); ?></label>
                                                        <p class="form-control-static"><?php echo e($apartment->beneficiary_mobile ?? '-'); ?></p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="form-control-label"><?php echo e(__('apartments.fields.beneficiary_email')); ?></label>
                                                        <p class="form-control-static"><?php echo e($apartment->beneficiary_email ?? '-'); ?></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__('common.close')); ?></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center py-4">
                                <p class="mb-0"><?php echo e(__('common.no_records')); ?></p>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <?php if($apartments->hasPages()): ?>
                <div class="d-flex justify-content-center mt-4">
                    <?php echo e($apartments->appends(request()->query())->links('vendor.pagination.bootstrap-5')); ?>

                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('styles'); ?>
<style>
    .dropdown-menu {
        min-width: 10rem;
        max-width: none;
        transform: none !important;
        left: auto !important;
        right: 0 !important;
        top: 100% !important;
        margin-top: 0.125rem !important;
    }
    .table-responsive {
        overflow: visible !important;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin_new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\alsafa\resources\views/admin/apartments/index.blade.php ENDPATH**/ ?>