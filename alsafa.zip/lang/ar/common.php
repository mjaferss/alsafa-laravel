<?php

return [
    'edit' => 'تعديل',
    'delete' => 'حذف',
    'confirm_delete' => 'هل أنت متأكد من عملية الحذف؟',
    'save' => 'حفظ',
    'cancel' => 'إلغاء',
    'back' => 'رجوع',
    'actions' => 'الإجراءات',
    'yes' => 'نعم',
    'no' => 'لا',
    'close' => 'إغلاق',
    'success' => 'تم بنجاح',
    'error' => 'حدث خطأ',
    'warning' => 'تحذير',
    'info' => 'معلومات',
]; 