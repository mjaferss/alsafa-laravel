<?php $__env->startSection('title', __('branches.list')); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><?php echo e(__('branches.list_title')); ?></h5>
                <?php if(in_array(auth()->user()->role, ['super_admin', 'manager'])): ?>
                    <a href="<?php echo e(route('admin.branches.create')); ?>" class="btn btn-primary btn-sm">
                        <i class="fas fa-plus me-2"></i> <?php echo e(__('branches.add_new')); ?>

                    </a>
                <?php endif; ?>
            </div>
            <div class="mt-3">
                <form action="<?php echo e(route('admin.branches.index')); ?>" method="GET" class="row g-3">
                    <div class="col-md-4">
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-search"></i></span>
                            <input type="text" class="form-control" name="search" placeholder="<?php echo e(__('common.search')); ?>" value="<?php echo e(request('search')); ?>">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <select class="form-select" name="is_active">
                            <option value=""><?php echo e(__('branches.fields.status')); ?></option>
                            <option value="1" <?php echo e(request('is_active') == '1' ? 'selected' : ''); ?>><?php echo e(__('common.active')); ?></option>
                            <option value="0" <?php echo e(request('is_active') == '0' ? 'selected' : ''); ?>><?php echo e(__('common.inactive')); ?></option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100"><?php echo e(__('common.search')); ?></button>
                    </div>
                    <div class="col-md-2">
                        <a href="<?php echo e(route('admin.branches.index')); ?>" class="btn btn-secondary w-100"><?php echo e(__('common.reset')); ?></a>
                    </div>
                </form>
            </div>
        </div>
        <div class="card-body px-0 pt-0 pb-2">
            <div class="table-responsive p-0">
                <table class="table align-items-center mb-0">
                    <thead>
                        <tr>
                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                <?php echo e(app()->getLocale() == 'ar' ? __('branches.fields.name_ar') : __('branches.fields.name_en')); ?>

                            </th>
                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 d-none d-md-table-cell"><?php echo e(__('branches.fields.phone')); ?></th>
                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7"><?php echo e(__('branches.fields.status')); ?></th>
                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 d-none d-md-table-cell"><?php echo e(__('branches.fields.created_at')); ?></th>
                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 text-center"><?php echo e(__('common.actions')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="align-middle">
                                <div class="d-flex px-2 py-1">
                                    <div class="d-flex flex-column justify-content-center">
                                        <h6 class="mb-0 text-sm">
                                            <?php echo e(app()->getLocale() == 'ar' ? $branch->name_ar : $branch->name_en); ?>

                                        </h6>
                                        <p class="text-xs text-secondary mb-0 d-md-none">
                                            <?php echo e($branch->phone); ?>

                                        </p>
                                    </div>
                                </div>
                            </td>
                            <td class="align-middle d-none d-md-table-cell">
                                <p class="text-sm font-weight-bold mb-0"><?php echo e($branch->phone); ?></p>
                            </td>
                            <td class="align-middle">
                                <span class="badge <?php echo e($branch->is_active ? 'bg-success' : 'bg-danger'); ?>">
                                    <?php echo e($branch->is_active ? __('common.active') : __('common.inactive')); ?>

                                </span>
                            </td>
                            <td class="align-middle d-none d-md-table-cell">
                                <p class="text-sm font-weight-bold mb-0"><?php echo e($branch->created_at->format('Y-m-d')); ?></p>
                            </td>
                            <td class="align-middle text-center text-sm">
                                <div class="dropdown">
                                    <button class="btn btn-sm btn-icon-only text-dark mb-0" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        <i class="fas fa-ellipsis-v"></i>
                                    </button>
                                    <ul class="dropdown-menu dropdown-menu-end">
                                        <li>
                                            <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#viewBranchModal<?php echo e($branch->id); ?>">
                                                <i class="fas fa-eye me-2"></i> <?php echo e(__('branches.actions.view')); ?>

                                            </a>
                                        </li>
                                        <?php if(in_array(auth()->user()->role, ['super_admin', 'manager'])): ?>
                                            <li>
                                                <a class="dropdown-item" href="<?php echo e(route('admin.branches.edit', $branch)); ?>">
                                                    <i class="fas fa-edit me-2"></i> <?php echo e(__('branches.actions.edit')); ?>

                                                </a>
                                            </li>
                                            <li>
                                                <form action="<?php echo e(route('admin.branches.destroy', $branch)); ?>" method="POST" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="dropdown-item" onclick="return confirm('<?php echo e(__('branches.confirmations.delete')); ?>')">
                                                        <i class="fas fa-trash me-2"></i> <?php echo e(__('branches.actions.delete')); ?>

                                                    </button>
                                                </form>
                                            </li>
                                            <li>
                                                <form action="<?php echo e(route('admin.branches.toggle-status', $branch)); ?>" method="POST" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="dropdown-item">
                                                        <i class="fas <?php echo e($branch->is_active ? 'fa-ban' : 'fa-check'); ?> me-2"></i>
                                                        <?php echo e($branch->is_active ? __('branches.deactivate') : __('branches.activate')); ?>

                                                    </button>
                                                </form>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </td>
                        </tr>

                        <!-- View Branch Modal -->
                        <div class="modal fade" id="viewBranchModal<?php echo e($branch->id); ?>" tabindex="-1" aria-labelledby="viewBranchModalLabel<?php echo e($branch->id); ?>" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="viewBranchModalLabel<?php echo e($branch->id); ?>"><?php echo e(__('branches.details')); ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <?php if(in_array(auth()->user()->role, ['super_admin', 'manager'])): ?>
                                            <div class="card card-body">
                                                <div class="row gx-4">
                                                    <div class="col-auto my-auto">
                                                        <div class="h-100">
                                                            <h5 class="mb-1"><?php echo e(app()->getLocale() == 'ar' ? $branch->name_ar : $branch->name_en); ?></h5>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row mt-4">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="form-control-label"><?php echo e(__('branches.fields.name_ar')); ?></label>
                                                            <p class="form-control-static"><?php echo e($branch->name_ar); ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="form-control-label"><?php echo e(__('branches.fields.name_en')); ?></label>
                                                            <p class="form-control-static"><?php echo e($branch->name_en); ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="form-control-label"><?php echo e(__('branches.fields.address_ar')); ?></label>
                                                            <p class="form-control-static"><?php echo e($branch->address_ar); ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="form-control-label"><?php echo e(__('branches.fields.address_en')); ?></label>
                                                            <p class="form-control-static"><?php echo e($branch->address_en); ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="form-control-label"><?php echo e(__('branches.fields.phone')); ?></label>
                                                            <p class="form-control-static"><?php echo e($branch->phone); ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="form-control-label"><?php echo e(__('branches.fields.status')); ?></label>
                                                            <p class="form-control-static">
                                                                <span class="badge <?php echo e($branch->is_active ? 'bg-success' : 'bg-danger'); ?>">
                                                                    <?php echo e($branch->is_active ? __('common.active') : __('common.inactive')); ?>

                                                                </span>
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="form-control-label"><?php echo e(__('branches.fields.created_at')); ?></label>
                                                            <p class="form-control-static"><?php echo e($branch->created_at->format('Y-m-d H:i')); ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="form-control-label"><?php echo e(__('branches.fields.updated_at')); ?></label>
                                                            <p class="form-control-static"><?php echo e($branch->updated_at->format('Y-m-d H:i')); ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php else: ?>
                                            <div class="alert alert-warning">
                                                <?php echo e(__('branches.unauthorized_access')); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__('common.close')); ?></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center py-4">
                                <p class="mb-0"><?php echo e(__('common.no_records')); ?></p>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <div class="d-flex justify-content-center mt-4">
                    <?php echo e($branches->appends(request()->query())->links('vendor.pagination.bootstrap-5')); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.querySelectorAll('.toggle-status').forEach(button => {
        button.addEventListener('click', function() {
            const branchId = this.dataset.branchId;
            const currentStatus = this.dataset.status;
            
            fetch(`/admin/branches/${branchId}/toggle-status`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update button appearance
                    this.classList.toggle('btn-secondary');
                    this.classList.toggle('btn-success');
                    
                    // Update icon
                    const icon = this.querySelector('i');
                    icon.classList.toggle('fa-ban');
                    icon.classList.toggle('fa-check');
                    
                    // Update status badge
                    const statusBadge = this.closest('tr').querySelector('.badge');
                    statusBadge.classList.toggle('bg-gradient-success');
                    statusBadge.classList.toggle('bg-gradient-danger');
                    statusBadge.textContent = currentStatus == 1 
                        ? '<?php echo e(__("branches.status.inactive")); ?>'
                        : '<?php echo e(__("branches.status.active")); ?>';
                    
                    // Update data attribute
                    this.dataset.status = currentStatus == 1 ? '0' : '1';
                    
                    // Show success message
                    Swal.fire({
                        icon: 'success',
                        title: '<?php echo e(__("common.success")); ?>',
                        text: data.message,
                        timer: 1500,
                        showConfirmButton: false
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.fire({
                    icon: 'error',
                    title: '<?php echo e(__("common.error")); ?>',
                    text: '<?php echo e(__("common.something_went_wrong")); ?>'
                });
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .btn {
        min-width: 40px;
    }
    .modal-dialog {
        max-width: 600px;
    }
    .table td .btn {
        padding: 0.5rem 1rem;
    }
    .table td .d-flex.gap-2 {
        gap: 0.5rem !important;
    }
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin_new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\alsafa\resources\views/admin/branches/index.blade.php ENDPATH**/ ?>