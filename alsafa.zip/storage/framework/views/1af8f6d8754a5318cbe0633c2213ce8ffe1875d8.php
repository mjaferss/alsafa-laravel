<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'title',
    'value',
    'icon',
    'color',
    'route' => null
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'title',
    'value',
    'icon',
    'color',
    'route' => null
]); ?>
<?php foreach (array_filter(([
    'title',
    'value',
    'icon',
    'color',
    'route' => null
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="col-12 col-sm-6 col-xl-3">
    <div class="card h-100">
        <div class="card-body">
            <div class="d-flex align-items-center justify-content-between mb-2">
                <div class="d-flex align-items-center">
                    <div class="fs-4 me-2"><i class="fas fa-<?php echo e($icon); ?> text-<?php echo e($color); ?>"></i></div>
                    <h6 class="card-title mb-0"><?php echo e($title); ?></h6>
                </div>
                <?php if($route): ?>
                <div class="dropdown">
                    <button class="btn btn-link text-muted p-0" data-bs-toggle="dropdown">
                        <i class="fas fa-ellipsis-v"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="<?php echo e($route); ?>"><?php echo e(__('common.view_all')); ?></a></li>
                    </ul>
                </div>
                <?php endif; ?>
            </div>
            <h2 class="mb-0"><?php echo e($value); ?></h2>
        </div>
    </div>
</div>
<?php /**PATH D:\alsafa\resources\views/components/stats-card.blade.php ENDPATH**/ ?>